# Exact Edit

Blender add-on for performing precise transformations to objects and geometry.

Please view the wiki page for full documentation:

https://github.com/n-Burn/Exact_Edit/wiki
